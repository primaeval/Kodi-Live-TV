import urllib, urllib2, os, io, xbmc, xbmcaddon, xbmcgui, json, re, base64

AddonID = 'plugin.video.kodilivetv'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
AddonName = Addon.getAddonInfo("name")
addonDir = Addon.getAddonInfo('path').decode("utf-8")
chanDir = os.path.join(addonDir, 'resources', 'channels')

def OpenURL(url, headers={}, user_data={}, justCookie=False):
	
    pw = False
    if url.find("@")>0:
        
        URL1 = url.split("@")[0]
        
        if url.startswith("http"):
            nurl = "http://" + url.split("@")[1]
        else:
            nurl = "https://" + url.split("@")[1]
            
        URL1 = url.replace("http://","").replace("https://","")
        us = URL1.split(":")[0]
        pw = URL1.split(":")[1]
        pw = pw.split("@")[0]
        url = nurl
    
    req = urllib2.Request(url)
    if pw:
        base64string = base64.encodestring('%s:%s' % (us, pw)).replace('\n', '')
        req.add_header("Authorization", "Basic %s" % base64string)
    
    req.add_header('User-Agent', 'Kodi Live TV')
    req.add_header('referer', url)
    
    for k, v in headers.items():
            req.add_header(k, v)
            
    response = urllib2.urlopen(req)
    
    if justCookie == True:
            if response.info().has_key("Set-Cookie"):
                    data = response.info()['Set-Cookie']
            else:
                    data = None
    else:
            data = response.read().replace("\r", "")
    
    response.close()
    return data

def ReadFile(fileName):
    try:
        f = open(fileName,'r')
        content = f.read().replace("\n\n", "\n")
        f.close()
    except:
        content = ""

    return content
	
def ReadList(fileName):
    try:
        with open(fileName, 'r') as handle:
            content = json.load(handle)
    except:
        content=[]

    return content

def SaveList(filname, list):
    try:
        with io.open(filname, 'w', encoding='utf-8') as handle:
                handle.write(unicode(json.dumps(list, indent=4, ensure_ascii=False)))
        success = True
    except Exception as ex:
        print ex
        success = False
            
    return success

def OKmsg(title, line1, line2 = None, line3 = None):
    dlg = xbmcgui.Dialog()
    dlg.ok(title, line1, line2, line3)
	

def m3u2list(url):
    if check_url(url):
        response = OpenURL(url)
    else:
        if not os.path.isfile(os.path.join(chanDir ,url)):
            url = url.replace(os.path.join(chanDir) + "/","")
            url = url.replace(os.path.join(chanDir) + "\\","")
            url = base64.decodestring(url)
            response = OpenURL(url)
        else:    
            response = ReadFile(url)
		
    matches=re.compile('^#EXTINF:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
    li = []
    for params, display_name, url in matches:
        item_data = {"params": params, "display_name": display_name, "url": url}
        li.append(item_data)

    list = []
    for channel in li:
        item_data = {"params": channel["params"], "display_name": channel["display_name"], "url": channel["url"]}
        matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
        for field, value in matches:
            item_data[field.strip().lower().replace('-', '_')] = value.strip()
        list.append(item_data)
    return list
	
def GetEncodeString(string):
    try:
        import chardet
        string = string.decode(chardet.detect(string)["encoding"]).encode("utf-8")
    except:
        pass
    return string

def DelFile(filname):
    try:
        if os.path.isfile(filname):
            os.unlink(filname)
    except Exception as e:
        print e

def BBTagRemove(string):
    
    string = re.sub(r"\[/COLOR]|\[COLOR.*?]","",string)
    string = re.sub(r"\[/B]|\[B]","",string)    
    return string

        
def Open_Netflix():
    import subprocess, sys
    xbmc.audioSuspend()
    ret = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "id": 0, "method": "Settings.getSettingValue", "params": {"setting":"screensaver.mode" } }')
    jsn = json.loads(ret)
    saver_mode = jsn['result']['value']
    xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "id": 0, "method":"Settings.setSettingValue", "params": {"setting":"screensaver.mode", "value":""} } ' )
    browser = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('browser')
    if 'linux' in sys.platform:
        if browser == "Chrome" :
            CHROME = os.path.join('/', 'opt', 'google', 'chrome', 'google-chrome')
            if not os.path.isfile(CHROME): CHROME = os.path.join('/', 'usr', 'bin', 'google-chrome')
            subprocess.call([CHROME , '--start-maximized','--disable-translate','--disable-new-tab-first-run','--no-default-browser-check','--no-first-run','--kiosk','--app=https://www.netflix.com/browse'])
            #process = subprocess.Popen(os.path.join(os.path.join(addonDir),"chrome.sh"), shell=True)
        else :
            CHROMIUM = os.path.join('/', 'usr', 'bin', 'chromium')
            if not os.path.isfile(CHROMIUM): CHROMIUM = os.path.join('/', 'usr', 'bin', 'chromium-browser')
            subprocess.call([CHROMIUM , '--start-maximized','--disable-translate','--disable-new-tab-first-run','--no-default-browser-check','--no-first-run','--kiosk','--app=https://www.netflix.com/browse'])
            #process = subprocess.Popen(os.path.join(os.path.join(addonDir),"chromium.sh"), shell=True)
        #process.wait()
    if 'win32' in sys.platform:
        if browser == "Chrome" :
            process = subprocess.Popen(os.path.join(os.path.join(addonDir),"chrome.cmd"), shell=True)
        else :
            process = subprocess.Popen(os.path.join(os.path.join(addonDir),"iexplore.cmd"), shell=True)
        process.wait()
    if 'darwin' in sys.platform:
        CHROME = os.path.join('/', 'Applications', 'Google Chrome.app', 'Contents', 'MacOS', 'Google Chrome')
        subprocess.call([CHROMIUM , '--start-fullscreen','--kiosk','https://www.netflix.com/browse'])
        #process = subprocess.Popen(os.path.join(os.path.join(addonDir),"darwin.sh"), shell=True)
        #process.wait()
    xbmc.audioResume()
    xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "id": 0, "method": "Settings.SetSettingValue", "params": {"setting":"screensaver.mode", "value": "'+saver_mode+'" } }')

def Open_Paypal():
    import subprocess, sys, json
    xbmc.audioSuspend()
    ret = xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "id": 0, "method": "Settings.getSettingValue", "params": {"setting":"screensaver.mode" } }')
    jsn = json.loads(ret)
    saver_mode = jsn['result']['value']
    xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "id": 0, "method":"Settings.setSettingValue", "params": {"setting":"screensaver.mode", "value":""} } ' )
    browser = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('browser')
    if 'linux' in sys.platform:
        if browser == "Chrome" :
            CHROME = os.path.join('/', 'opt', 'google', 'chrome', 'google-chrome')
            if not os.path.isfile(CHROME): CHROME = os.path.join('/', 'usr', 'bin', 'google-chrome')
            subprocess.call([CHROME , '--start-maximized','--disable-translate','--disable-new-tab-first-run','--no-default-browser-check','--no-first-run','--kiosk','--app=http://paypal.me/kodilive'])
            #process = subprocess.Popen(os.path.join(os.path.join(addonDir),"chrome.sh"), shell=True)
        else :
            CHROMIUM = os.path.join('/', 'usr', 'bin', 'chromium')
            if not os.path.isfile(CHROMIUM): CHROMIUM = os.path.join('/', 'usr', 'bin', 'chromium-browser')
            subprocess.call([CHROMIUM , '--start-maximized','--disable-translate','--disable-new-tab-first-run','--no-default-browser-check','--no-first-run','--kiosk','--app=http://paypal.me/kodilive'])
            #process = subprocess.Popen(os.path.join(os.path.join(addonDir),"chromium.sh"), shell=True)
        #process.wait()
    if 'win32' in sys.platform:
        if browser == "Chrome" :
            process = subprocess.Popen(os.path.join(os.path.join(addonDir),"offer.cmd"), shell=True)
        else :
            process = subprocess.Popen(os.path.join(os.path.join(addonDir),"offeri.cmd"), shell=True)
        process.wait()
    if 'darwin' in sys.platform:
        CHROME = os.path.join('/', 'Applications', 'Google Chrome.app', 'Contents', 'MacOS', 'Google Chrome')
        subprocess.call([CHROMIUM , '--start-fullscreen','--kiosk','http://paypal.me/kodilive'])
    xbmc.audioResume()
    xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "id": 0, "method": "Settings.SetSettingValue", "params": {"setting":"screensaver.mode", "value": "'+saver_mode+'" } }')

def check_url(url):
    import urlparse
    parts = urlparse.urlsplit(url)
    if not parts.scheme or not parts.netloc:
        return False
    else:
        return True
