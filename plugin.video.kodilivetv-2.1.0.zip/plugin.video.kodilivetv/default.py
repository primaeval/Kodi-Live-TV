# -*- coding: utf-8 -*-
#code by Vania 
import urllib2, urllib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, shutil, time, zipfile, re, stat, xbmcvfs, base64

# Definizione variabili globali

AddonID = 'plugin.video.kodilivetv'
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString
AddonName = Addon.getAddonInfo("name")
icon = Addon.getAddonInfo('icon')

addonDir = Addon.getAddonInfo('path').decode("utf-8")
addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID)
pwdir = os.path.join(addon_data_dir, "password")
cdir = os.path.join(xbmc.translatePath("special://temp"),"files")

LOCAL_VERSION_FILE = os.path.join(os.path.join(addonDir), 'version.xml' )
REMOTE_VERSION_FILE = "http://kodilive.eu/repo/version.xml"

LOCAL_VERSION_FILE2 = os.path.join(os.path.join(addonDir), 'list.xml' )
REMOTE_VERSION_FILE2 = "http://kodilive.eu/update/list.xml"

libDir = os.path.join(addonDir, 'resources', 'lib')
f4mProxy = os.path.join(addonDir, 'f4mProxy')
chanDir = os.path.join(addonDir, 'resources', 'channels')

XML_FILE  = os.path.join(libDir, 'advancedsettings.xml' )
ACTIVESETTINGSFILE = os.path.join(xbmc.translatePath('special://profile'), 'advancedsettings.xml')

PATCH_SD = os.path.join(addonDir, 'resources', 'patch', 'SimpleDownloader.py')
SD_FILE = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8") , 'script.module.simple.downloader' , 'lib', 'SimpleDownloader.py')
PATCHED = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8") , 'script.module.simple.downloader' , '.SDP')

playlistsFile = os.path.join(addonDir, "playLists.txt")
Italian = os.path.join(addonDir, "italian.txt")
French = os.path.join(addonDir, "french.txt")
German = os.path.join(addonDir, "german.txt")
English = os.path.join(addonDir, "english.txt")
#f4m = os.path.join(addonDir, "f4m.txt")

playlistsFile2 = os.path.join(addon_data_dir, "playLists.txt")
playlistsFile4 = os.path.join(addon_data_dir, "FolderLists.txt")
playlistsFile3 = os.path.join(addon_data_dir, "playLists.bkp")

tmpListFile = os.path.join(addon_data_dir, 'tempList.txt')
favoritesFile = os.path.join(addon_data_dir, 'favorites.txt')
SDownloader = "false"

# Inizializzazione file favoriti

if  not (os.path.isfile(favoritesFile)):
    f = open(favoritesFile, 'w') 
    f.write('[]') 
    f.close()

# Crezione cartelle

if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)
if not os.path.exists(pwdir):
	os.makedirs(pwdir)	
if not os.path.exists(cdir):
	os.makedirs(cdir)

# Importo funzioni da common.py

sys.path.insert(0, libDir)
import common

# Installazione dipendenze mancanti (aggiornamento vecchie versioni)

dependspath = xbmc.translatePath(os.path.join('special://home/addons','script.module.simplejson'))
if not os.path.exists(dependspath):
    dest = os.path.join(addonDir, 'resources', 'zip') + '/script.module.simplejson.zip'
    extpath = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8")) 
    ZIP_URL = 'http://mirrors.xbmc.org/addons/jarvis/script.module.simplejson/script.module.simplejson-3.3.0.zip'
    urllib.urlretrieve(ZIP_URL,dest)
    import ziptools
    unzipper = ziptools.ziptools()
    unzipper.extract(dest,extpath)
    os.remove( dest )  
    xbmc.log('TEMPORARY ZIP REMOVED')

    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,"script.module.simplejson installed", 3500, icon))
    xbmc.sleep(1500)
    
dependspath2 = xbmc.translatePath(os.path.join('special://home/addons','script.module.requests'))
if not os.path.exists(dependspath2):
    dest = os.path.join(addonDir, 'resources', 'zip') + '/script.module.requests.zip'
    extpath = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8")) 
    ZIP_URL = 'http://mirrors.xbmc.org/addons/jarvis/script.module.requests/script.module.requests-2.9.1.zip'
    urllib.urlretrieve(ZIP_URL,dest)
    import ziptools
    unzipper = ziptools.ziptools()
    unzipper.extract(dest,extpath)    
    os.remove( dest )  
    xbmc.log('TEMPORARY ZIP REMOVED')

    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,"script.module.requests installed", 3500, icon))

# Funzioni gestione file

def find_single_match(data,patron,index=0):
    
    try:
        matches = re.findall( patron , data , flags=re.DOTALL )
        return matches[index]
    except:
        return ""

percent = 0

def DownloaderClass(url,dest):
    
    dp = xbmcgui.DialogProgress()
    dp.create("Kodi Live TV ZIP DOWNLOADER","Downloading File",url)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except: 
        percent = 100
        dp.update(percent)
        time.sleep(20)
        dp.close()
    if dp.iscanceled(): 
        dp.close()


def write_file(file_name, file_contents):
    fh = None
    try:
        fh = open(file_name, "wb")
        fh.write(file_contents)
        return True
    except:
        return False
    finally:
	if fh is not None:
	    fh.close()

def emptydir(top):
    
    if(top == '/' or top == "\\"): 
        return
    else:
        for root, dirs, files in os.walk(top, topdown=False):
            for name in files:
                if not bool('default.py' in name) and not bool('ziptools.py' in name):
                    os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name)) 
 
def clean_cache():

    for i in os.listdir(cdir):    
        rf = format(i)
        if not bool('.' in i):
            file = os.path.join( cdir , i )
            if os.path.isfile(file):
                os.remove(file)
                xbmc.log('KLTV Delete cache file : ' + rf )
        else:
            pass

##############################
# Inizia creazione pagine
    
def Categories():
    AddDir("[COLOR ff74ff4a][B]{0}[/B][/COLOR]".format(localizedString(10106).encode('utf-8')), "update" ,46 ,os.path.join(addonDir, "resources", "images", "update.png"), isFolder=True)
    AddDir("[COLOR cyan][B][ {0} ][/B][/COLOR]".format(localizedString(10003).encode('utf-8')), "favorites" ,30 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"))
    AddDir("[COLOR blue][B]{0}[/B][/COLOR]".format(localizedString(10047).encode('utf-8')), "Manager" ,39 , os.path.join(addonDir, "resources", "images", "playlist.png"))
    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10020).encode('utf-8')), "italian" ,35 , "http://kodilive.eu/flag/it.png")
    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10021).encode('utf-8')), "french" ,36 , "http://kodilive.eu/flag/fr.png")
    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10022).encode('utf-8')), "german" ,37 , "http://kodilive.eu/flag/de.png")
    AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format(localizedString(10023).encode('utf-8')), "english" ,38 ,  "http://kodilive.eu/flag/uk.png")
    list = common.ReadList(playlistsFile)
    for item in list:
            mode = 1 if item["url"].find(".plx") > 0 else 2
            image = item.get('image', '')
            icon = image.encode("utf-8")
            name = localizedString(item["name"])
            cname = "[COLOR gold][B]{0}[/B][/COLOR]".format(name)
            
            if name == localizedString(10070).encode('utf-8') :
                cname = "[COLOR violet][B]{0}[/B][/COLOR]".format(name)
            elif name == localizedString(10050).encode('utf-8') :
                cname = "[COLOR pink][B]{0}[/B][/COLOR]".format(name)
            elif name == localizedString(10051).encode('utf-8') :
                cname = "[COLOR FED9DB93][B]{0}[/B][/COLOR]".format(name)                    
            AddDir(cname ,item["url"], mode , icon)

def importList():
    
    method = GetSourceLocation(localizedString(10120).encode('utf-8'), [localizedString(10122).encode('utf-8'), localizedString(10123).encode('utf-8')])
        
    if method == -1:
            return
    elif method == 0:
            listUrl = GetKeyboardText(localizedString(10005).encode('utf-8')).strip()
    else:
            listUrl = xbmcgui.Dialog().browse(int(1), localizedString(10006).encode('utf-8'), 'myprograms','.txt').decode("utf-8")
            if not listUrl:
                    return
    if len(listUrl) < 1:
            return
 
    if common.check_url(listUrl):
            lista = common.OpenURL(listUrl)
    else:
            lista = common.ReadFile(listUrl)
 
    if os.path.isfile( playlistsFile3 ) : os.remove( playlistsFile3 )
    shutil.copyfile( playlistsFile2, playlistsFile3 )
    xbmc.sleep ( 500 )
    os.remove( playlistsFile2 )
    xbmc.sleep ( 500 )
    write_file( playlistsFile2, lista )
    xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Kodi Live TV : ",localizedString(10124).encode('utf-8'), 3600, icon))    
  
def AddNewList():
	
    method1 = GetSourceLocation(localizedString(10001).encode('utf-8'), [localizedString(10040).encode('utf-8'), localizedString(10043).encode('utf-8'), localizedString(10204).encode('utf-8'), localizedString(10042).encode('utf-8')])
	
    if method1 == -1:
            return	
    elif method1 == 0:
        AddNewDir()
    elif method1 == 1:
        AddNewDir("rf")
    elif method1 == 2:
        AddNewDir("repo")
    else:
        listName = GetKeyboardText(localizedString(10004).encode('utf-8')).strip()
        if len(listName) < 1:
                return

        method = GetSourceLocation(localizedString(10002).encode('utf-8'), [localizedString(10016).encode('utf-8'), localizedString(10017).encode('utf-8')])	

        if method == -1:
                return
        elif method == 0:
                listUrl = GetKeyboardText(localizedString(10005).encode('utf-8')).strip()
        else:
                listUrl = xbmcgui.Dialog().browse(int(1), localizedString(10006).encode('utf-8'), 'myprograms','.plx|.m3u').decode("utf-8")
                if not listUrl:
                        return
            
        if len(listUrl) < 1:
                return

        list = common.ReadList(playlistsFile2)

        list.append({"name": listName.decode("utf-8"), "url": listUrl})
        if common.SaveList(playlistsFile2, list):
                xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
                    
def AddNewDir(loc = "l"):
    if loc == "l":
        listUrl = xbmcgui.Dialog().browse(int(0), localizedString(10041).encode('utf-8'), 'myprograms').decode("utf-8")
    elif loc == "rf":
        listUrl = xbmcgui.Dialog().browse(int(0), localizedString(10041).encode('utf-8'), 'files').decode("utf-8")
    else:
        listUrl = xbmcgui.Dialog().browse(int(1), localizedString(10041).encode('utf-8'), 'myprograms', mask='.xml').decode("utf-8")
            
    if not listUrl:
            return    
	
    if len(listUrl) < 1:
            return

    list = common.ReadList(playlistsFile4)
    if listUrl.endswith(".xml"):
        f = open(listUrl,'r')
        data = f.read().replace("\n\n", "")
        f.close() 
            
        listUrl = find_single_match(data,"<url>([^<]+)</url>").strip()
        listName = find_single_match(data,"<name>([^<]+)</name>").strip()
           
    else:
        listName = listUrl.replace('\\','/')
        listName = listName.split("/")[-2]
            
    list.append({"name": listName.decode("utf-8"), "url": listUrl})
    if common.SaveList(playlistsFile4, list):
            xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
	
def RemoveFromLists(url):
    
    list = common.ReadList(playlistsFile2)
    for item in list:
            if item["url"] == url:
                    list.remove(item)
                    if common.SaveList(playlistsFile2, list):
                            xbmc.executebuiltin("XBMC.Container.Refresh()")
                    break
			
def RemoveDirFromLists(url , name):
    
    return_value = xbmcgui.Dialog().yesno(localizedString(10045).encode('utf-8'), localizedString(10206).encode('utf-8') + " " + name + " ?")
    if not return_value == 0:
        
        list = common.ReadList(playlistsFile4)
        for item in list:
                if item["url"] == url:
                        list.remove(item)
                        if common.SaveList(playlistsFile4, list):
                                xbmc.executebuiltin("XBMC.Container.Refresh()")
                        break

def TempFileName (url):
    
    TempName = base64.standard_b64encode(url)
    return os.path.join(cdir, TempName)
				
def m3uCategory(url,Logo=True):
    
    if not common.check_url(url):
        
        list = common.m3u2list(os.path.join(chanDir, url)) 
        	
        for channel in list:
            name = channel["display_name"]

            if channel.get("tvg_logo", ""): 
                logo = channel.get("tvg_logo", "")
                iconname = "http://kodilive.eu/logo/" + logo
            else :
                logo = "tv.png"
                iconname = os.path.join(addonDir, "resources", "images", logo)
            if Logo == False:
                if channel.get("tvg_logo", "") and common.check_url(channel.get("tvg_logo", "")):
                    iconname = channel.get("tvg_logo", "")
                else:
                    logo = "tv.png"
                    iconname = os.path.join(addonDir, "resources", "images", logo)
                
            AddDir(name ,channel["url"], 3, iconname, isFolder=False)
        
    else :
        tmp = TempFileName(url)
	tcache = 7200
	
	if os.path.isfile(tmp):
            t = time.time() - os.path.getmtime(tmp)
        else :
            t = 0
            
	if os.path.isfile(tmp) and t < tcache:
            list = common.m3u2list(tmp)
        else :   
            list = common.m3u2list(url)
                
	for channel in list:
		name = common.GetEncodeString(channel["display_name"])

                if channel.get("tvg_logo", ""): 
                    logo = channel.get("tvg_logo", "")
                    iconname = "http://kodilive.eu/logo/" + logo
                else :
                    logo = "tv.png"
                    iconname = os.path.join(addonDir, "resources", "images", logo)
                
                if Logo == False:
                    if channel.get("tvg_logo", "") and common.check_url(channel.get("tvg_logo", "")):
                        iconname = channel.get("tvg_logo", "")
                    else:
                        logo = "tv.png"
                        iconname = os.path.join(addonDir, "resources", "images", logo)
                
		AddDir(name ,channel["url"], 3, iconname, isFolder=False)
        
        if not os.path.isfile(tmp) or t > tcache :
                content = common.OpenURL(url)
                if len(content) > 10 :
                    write_file(tmp, content) 
                    xbmc.log('Write temp list : ' + tmp + '- size : ' + format( len(content) ) )
                     
    
def PlayUrl(name, url, iconimage=None):
    
    url=url.replace("\n","").replace("\r","")
    if not url.endswith(".ts") and not url.endswith(".f4m") and url.find(".f4m?") < 0 and not url.endswith("Player=HLS"):
        if url.endswith("?time="):
            url = url + str(time.time())
        print '--- Playing "{0}". {1}'.format(name, url)
        listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
        listitem.setInfo(type="Video", infoLabels={ "Title": name })
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
        xbmc.sleep(100)
        xbmc.executebuiltin('Dialog.Close(all, true)')
                
    else :
        if xbmc.Player().isPlaying():
            xbmc.executebuiltin( "XBMC.Action(Stop)" )
            xbmc.sleep(4000)
            xbmc.executebuiltin('Dialog.Close(all, true)')

        if Addon.getSetting('use_shani') == "true":
            MyF4m = False
        else:
            MyF4m = True
            
        if url.endswith(".ts"):        
            StreamType = 'TSDOWNLOADER'
        elif url.find("Player=HLS") > 0:
            StreamType = 'HLS'
        else:
            StreamType = 'HDS'
            
        if MyF4m :
            url = 'plugin://plugin.video.kodilivetv/?url='+urllib.quote_plus(url)+'&streamtype=' + StreamType + '&name='+urllib.quote(name)+'&mode=5&iconimage=' + iconimage
            xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
            xbmc.executebuiltin('Dialog.Close(all, true)')
        else:
            f4mDir = xbmcaddon.Addon('plugin.video.f4mTester').getAddonInfo('path').decode("utf-8")
            if not os.path.exists(f4mDir):
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,"Plugin f4mTester required!", 3200, icon))
            else:
                url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(url)+'&streamtype=' + StreamType + '&name='+urllib.quote(name)+'&iconImage=' + iconimage
                xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
                xbmc.executebuiltin('Dialog.Close(all, true)')


def VideoDownload(url,title,stop=False):
    
    url = url.replace("\r","").replace("\n","")
    url = url.strip()
    ext = url.split('.')[-1]
    title = title.replace("\r","").replace("\n","")
    title = title.strip()
    
    DF = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('download_path')
    
    if not DF=='':  
        dpath = DF
    else:    
        dpath = addon_data_dir
    
    if stop:
        params = { "url": url , "download_path": dpath , "quit":"true", "Title": title }
    else:
        params = { "url": url , "download_path": dpath , "Title": title }
    
    u = unicode(title, "utf-8")
    downloader.download( u + "." + ext, params)

def PMFolder( folder ):
    
    try:
        urldec = base64.decodestring(folder)
        if common.check_url(urldec):
            folder = urldec
    except:
        pass
    
    urlx = folder
    pw = ""
    
    if urlx.find("@")>0:
        US = ""
        URL1 = urlx.split("@")[0]
    
        if urlx.startswith("http:"):
            proto = "http://"
        else:
            proto = "https://" 
    
        URL1 = urlx.replace("http://","").replace("https://","")
        us = URL1.split(":")[0]
        pw = URL1.split(":")[1]
        pw = pw.split("@")[0]
        
        datafile =  os.path.join( pwdir , base64.standard_b64encode(folder))
        pwm = ""
        usm = ""
        t = 0
        
        if os.path.isfile(datafile):
            f = open(datafile,'r')
            data = f.read().replace("\n\n", "")
            f.close() 
            pwm = find_single_match(data,"<password>([^<]+)</password>").strip()
            if not pwm == "": 
                pw = pwm
            usm = find_single_match(data,"<username>([^<]+)</username>").strip()
            if not usm == "": 
                us = usm
            folder = proto + us + ":" + pw + "@" + urlx.split("@")[1]
            
        if pw =="x" :
            if not us == "x":
                US = us
            string = GetKeyboardText("Enter username", US)
            if len(string) < 1:
                return
            us = string
            if not pw == "x":
                p = pw
            else:
                p = ""
                
            string = GetKeyboardText("Enter password", p)
            if len(string) < 1:
                return
            pw = string
            folder = proto + us + ":" + pw + "@" + urlx.split("@")[1]
            if os.path.isfile(datafile):
                os.remove(datafile)
                xbmc.sleep(1200)
            
        if not os.path.isfile(datafile):
            content = "<username>" + us + "</username><password>" + pw + "</password>"
            write_file(datafile, content)

    
    DF =  folder
    dirs, files = xbmcvfs.listdir(DF)
    EXTL = [ '.m3u', '.m3u8', '.txt']
    EXTV = [ '.mkv','.mp4','.avi','.ogv','.flv','.f4v','.wmv','.mpg','.mpeg','.3gp','.3g2','.webm','.ogg' ]
    EXTA = [ '.mp3','.flac','.aac','.wav','.raw','.m4a','.wma','.f4a' ]
    EXT = EXTL + EXTV + EXTA 
    
    files.sort()
    
    iconlist = "http://findicons.com/files/icons/1331/matrix_rebooted/128/text_clipping_file.png"
    music = "http://findicons.com/files/icons/1331/matrix_rebooted/128/music.png"
    icondir = "http://findicons.com/files/icons/1331/matrix_rebooted/128/generic_folder_alt.png"
    video = "http://findicons.com/files/icons/1331/matrix_rebooted/128/movies_2.png"
                
    for i in dirs:
        rf = format(i)
        cname = "[COLOR cyan][B]{0}[/B][/COLOR]".format(rf)
        
        if common.check_url(DF):
            url = DF  + rf + "/"
        else:
            url = os.path.join(DF, rf)

        url = url.replace("\r","").replace("\n","").strip()
        cname = cname.replace("%20"," ").replace("\r","").replace("\n","").strip()
        AddDir(cname, url, 54, icondir, isFolder=True)
        
    for i in files:    
        rf = format(i)
        ext = "." + rf.split(".")[-1]
        Name = rf.replace("%20"," ").replace("\r","").replace("\n","").strip()
        
        if bool(ext in EXT) :
            
                if common.check_url(DF):
                    url = DF + rf
                else:
                    url = os.path.join(DF, rf)
		
		url = url.replace("\r","").replace("\n","").strip()

		if url.endswith(".m3u") or url.endswith(".txt") or url.endswith(".m3u8"):
                    cname = "[COLOR green][B]{0}[/B][/COLOR]".format(Name)
                    AddDir(cname, url, 51, iconlist, isFolder=True)
                else:
                    perc = -1
                    p = ""
                    EP = ""
                    
                    if os.path.isfile(url + ".resume"):
                        EP = ".resume"
                    elif os.path.isfile(url + ".stopped"):
                        EP = ".stopped"
                    else:
                        perc = -1
                    if not  EP == "":
                        PERC = common.ReadFile(url + EP).replace("\r","").split("\n")
                        perc = int(PERC[0])
                        
                        
                    if not perc <0:
                        size = 0
                        size = os.stat(url).st_size
                        
                        if size > 0:
                            perc = round((100.0*size)/int(perc), 2)
                            
                            col = "green"
                            
                            if perc <80:
                                col = "yellow"
                            if perc <55:
                                col = "orange"
                            if perc <35:
                                col = "orangered"
                            if perc <15:
                                col = "red"

                            p = " - [B][COLOR blue][ [COLOR " + col + "]" + str(perc) + "% [/COLOR]][/B][/COLOR]"
        
                    if bool(ext in EXTV):
                        icon = video
                    else:
                        icon = music
                    
                    cname = "[COLOR FFAAFFFF][B]{0}[/B][/COLOR]".format(Name) + p
                    AddDir(cname , url, 50 , icon, "", isFolder=False)


def TestDownload(name):
    
    size1 = os.stat(name).st_size
    for x in range(0, 4):
        xbmc.sleep(1500)
        size2 = os.stat(name).st_size
        if not size1 == size2:
            return False
            break
    return True


def AddDir(name, url, mode, iconimage, description="", isFolder=True, background=None):
    
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        
    url = url.replace('\n','')
    url = url.replace('\r','')
    url = url.strip()
    name = name.strip()
    name = common.GetEncodeString(name)

    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description})
    liz.setArt({'fanart': Addon.getAddonInfo('fanart')})
	
    if background:
            liz.setProperty('fanart_image', background)
    if mode == 4 or mode == 21 or mode == 51 or mode == 54 or mode == 50 or mode == 60:
            items = [ ]
                
            if mode == 21:
                items = [('{0}'.format(localizedString(10008).encode('utf-8')) + name, 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=55)'.format(sys.argv[0], urllib.quote_plus(url), name))]
                items.append(('{0}'.format(localizedString(10018).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=61)'.format(sys.argv[0], urllib.quote_plus(url), name)))
                try:
                    urldec = base64.decodestring(url)
                    if common.check_url(urldec):
                        url = urldec
                except:
                    pass
                
                if url.find("@")>0:
                    datafile = os.path.join( pwdir , base64.standard_b64encode(url) )
                    if os.path.isfile(datafile):
                        items.append((localizedString(10207).encode('utf-8'), 'XBMC.RunPlugin({0}?url={1}&mode=56)'.format(sys.argv[0], urllib.quote_plus(url))))
                        
            if mode == 4:
                items = [('{0}'.format(localizedString(10008).encode('utf-8')) + name, 'XBMC.RunPlugin({0}?url={1}&mode=22)'.format(sys.argv[0], urllib.quote_plus(url)))]
                items.append(('{0}'.format(localizedString(10018).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=23)'.format(sys.argv[0], urllib.quote_plus(url), name)))
                items.append(('{0}'.format(localizedString(10019).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=24)'.format(sys.argv[0], urllib.quote_plus(url), name)))
            if mode ==51 or mode == 50:
                name = common.BBTagRemove(name)
                if not common.check_url(url):
                    items = [('{0}'.format(localizedString(10205).encode('utf-8')) + ' : ' + name, 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=52)'.format(sys.argv[0], urllib.quote_plus(url), name))]
                        
            if mode == 50:
                ext = url.split('.')[-1]
                namefile = urllib.unquote(os.path.basename(url)).replace("." + ext,"")
                    
                if os.path.isfile( url + ".stopped"):
                    urlx = common.ReadFile(url + ".stopped").replace("\r","").split("\n")
                    items.append((localizedString(10213).encode('utf-8') + ' : ' + namefile, 'XBMC.RunPlugin({0}?url={1}&mode=7&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), iconimage, namefile)))
                elif os.path.isfile( url + ".resume"):
                    urlx = common.ReadFile(url + ".resume").replace("\r","").split("\n")
                    items.append((localizedString(10212).encode('utf-8') + ' : ' + namefile, 'XBMC.RunPlugin({0}?url={1}&mode=57&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(urlx[1]), iconimage, namefile)))
                        
            if mode ==51 or mode == 50:
                if not common.check_url(url):
                    if not os.path.isfile( url + ".stopped") and not os.path.isfile( url + ".resume"):
                        items.append(('{0}'.format(localizedString(10018).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=53)'.format(sys.argv[0], urllib.quote_plus(url), name)))
                    
                items.append(('Refresh', 'Container.Refresh'))
                liz.addContextMenuItems(items, replaceItems=True)
            else:
                liz.addContextMenuItems(items)
	
    if mode == 3:
            liz.setProperty('IsPlayable', 'true')
		
            items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))]
		
            if url.endswith('.mkv') or url.endswith('.mp4') or url.endswith('.avi'):
                if common.check_url(url):
                    name = name.replace(","," ")
                    name = name.replace("  "," ")
                        
                    if SDownloader == "true":
                        items.append(('Download: ' + name, 'XBMC.RunPlugin({0}?url={1}&mode=6&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name)))
                    else:
                        ext = url.split('.')[-1]
                        DF = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('download_path')
                            
                        if not DF=='':  
                            dpath = DF
                        else:    
                            dpath = addon_data_dir
                            
                        file = dpath + name + '.' + ext
                            
                        if os.path.isfile( file + ".stopped") and os.path.isfile( file):
                            items.append(('Download Resume : ' + name, 'XBMC.RunPlugin({0}?url={1}&mode=7&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name)))
                            items.append(('Delete Partial Download : ' + name, 'XBMC.RunPlugin({0}?url={1}&mode=58&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name)))
                        elif os.path.isfile( file + ".resume") and os.path.isfile( file):
                            items.append(('Stop Download : ' + name, 'XBMC.RunPlugin({0}?url={1}&mode=57&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name)))
                        else:
                            items.append(('Download : ' + name, 'XBMC.RunPlugin({0}?url={1}&mode=7&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name)))
		
            items.append(('Refresh', 'Container.Refresh'))
            liz.addContextMenuItems(items, replaceItems=True)
		
    elif mode == 32:
            liz.setProperty('IsPlayable', 'true')
            liz.addContextMenuItems(items = [('{0}'.format(localizedString(10010).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
	
    if mode == 20: 
            items = [('{0}'.format(localizedString(10120).encode('utf-8')) , 'XBMC.RunPlugin({0}?url={1}&mode=25)'.format(sys.argv[0], urllib.quote_plus(url), name)),  
                        ('{0}'.format(localizedString(10121).encode('utf-8')) , 'XBMC.RunPlugin({0}?url={1}&mode=26)'.format(sys.argv[0], urllib.quote_plus(url), name)) ]
            liz.addContextMenuItems(items , replaceItems=True)
	
    if mode == 30 or mode == 48 or mode == 49 or mode == 46 or mode == 34:
            liz.addContextMenuItems( [] , replaceItems=True)
                
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)

def PM_index():
    
    AddDir("[COLOR blue][B]{0}[/B][/COLOR]".format(localizedString(10001).encode('utf-8')), "settings" , 20, "http://findicons.com/files/icons/1331/matrix_rebooted/128/new_folder.png", isFolder=False)
    
    if not xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('download_path')== "":
        DD = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('download_path')
    else:
        AddonID = 'plugin.video.kodilivetv'
        DD = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID)  
            
    AddDir("[COLOR cyan][B]{0}[/B][/COLOR]".format(localizedString(10112).encode('utf-8')), DD , 60, "http://findicons.com/files/icons/1331/matrix_rebooted/128/drop_folder.png", isFolder=True)
    listDir = common.ReadList(playlistsFile4)
    for dir in listDir:
        name = "[COLOR cyan][B]{0}[/B][/COLOR]".format(dir["name"].encode("utf-8"))
        AddDir(name, dir["url"], 21, "http://findicons.com/files/icons/1331/matrix_rebooted/128/generic_folder_alt.png", isFolder=True)       
        
    list = common.ReadList(playlistsFile2)
    for channel in list:
        if channel["url"].find("://")>0:
            color = "FF00c100"
        else:
            color = "green"
            
        name = "[COLOR " + color + "][B]{0}[/B][/COLOR]".format(channel["name"].encode("utf-8"))
        AddDir(name, channel["url"], 4, "http://findicons.com/files/icons/1331/matrix_rebooted/128/text_clipping_file.png", isFolder=True)

def ChangeName(name, listFile, key, title):
    
    list = common.ReadList(listFile)
    name = re.sub('\[.*?]','',name)
    string = GetKeyboardText(localizedString(title), name)
    if len(string) < 1:
            return
    for channel in list:    
        if channel["url"].lower() == url.lower():
            channel["name"] = string.decode("utf-8")
            break
    if common.SaveList(listFile, list):
            xbmc.executebuiltin("XBMC.Container.Refresh()")
		
def ChangeUrl(name, listFile, key, title):
        
    list = common.ReadList(listFile)
    name = re.sub('\[.*?]','',name)
	
    if not common.check_url(url):
        string = xbmcgui.Dialog().browse(int(1), localizedString(10006).encode('utf-8'), 'myprograms','.plx|.m3u').decode("utf-8")
        if not string:
            return
    else:
        string = GetKeyboardText(localizedString(title), url)
            
    if len(string) < 1:
            return
    for channel in list:    
        if channel["url"] == url:
            channel["url"] = string.decode("utf-8")
            break
    if common.SaveList(listFile, list):
            xbmc.executebuiltin("XBMC.Container.Refresh()")
	
def GetKeyboardText(title = "", defaultText = ""):
    
    keyboard = xbmc.Keyboard(defaultText, title)
    keyboard.doModal()
    text =  "" if not keyboard.isConfirmed() else keyboard.getText()
    return text

def GetSourceLocation(title, list):
    
    dialog = xbmcgui.Dialog()
    answer = dialog.select(title, list)
    return answer
	
def AddFavorites(url, iconimage, name):
    
    favList = common.ReadList(favoritesFile)
    for item in favList:
            if item["url"].lower() == url.lower():
                    xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10011).encode('utf-8'), icon))
                    return
    
    list = common.ReadList(tmpListFile)	
    for channel in list:
            if channel["name"].lower() == name.lower():
                    url = channel["url"]
                    iconimage = channel["image"]
                    break
                    
    name = name.replace('\r','')

    url = url.replace('\n','')
    url = url.replace('\r','')
    url = url.strip()	
    if not iconimage:
        iconimage = ""
    else:
        iconimage = iconimage.replace('\r','')
        
    data = {"url": url, "image": iconimage, "name": name.decode("utf-8")}
	
    favList.append(data)
    common.SaveList(favoritesFile, favList)
    xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10012).encode('utf-8'), icon))
		
def ListFavorites():
    
    AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10013).encode('utf-8')), "favorites" ,34 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"), isFolder=False)
    if 'win32' or 'linux' or 'darwin' in sys.platform:
        AddDir("[COLOR red][B]{0}[/B][/COLOR]".format(localizedString(10099).encode('utf-8')) + " - Press [ALT] + [F4] to close", "Netflix" ,48 ,os.path.join(addonDir, "resources", "images", "netflix.png"), isFolder=False)
    if 'win32' or 'linux' or 'darwin' in sys.platform:
        AddDir("[COLOR gold][B]{0}[/B][/COLOR]".format((localizedString(10098)).encode('utf-8')) + " - Press [ALT] + [F4] to close", "Offer" ,49 , os.path.join(addonDir, "resources", "images", "paypal.png"), isFolder=False)
	
    list = common.ReadList(favoritesFile)
    for channel in list:
            name = channel["name"].encode("utf-8")
            iconimage = channel["image"].encode("utf-8")
            if iconimage=="":
                iconimage = os.path.join(addonDir, "resources", "images", "tv.png") 
            AddDir(name, channel["url"], 32, iconimage, isFolder=False) 

def ListSub(lng):
    
    list = common.ReadList(lng)
    for item in list:
            mode =  2
            image = item.get('image', '')
            if not "http" in image:
                    icon = os.path.join(addonDir, "resources", "images", image.encode("utf-8"))
            else:
                    icon = image.encode("utf-8")
                 
            try:
                name = int(item["name"])
                name = localizedString(name)
            except:
                name = item["name"]
                    
            cname = "[COLOR gold][B]{0}[/B][/COLOR]".format(name)
            AddDir(cname ,item["url"], mode , icon, "")

def ListTB(lg):
    
    ok = show_main(lg)

def RemoveFavorties(url):
    
    list = common.ReadList(favoritesFile) 
    for channel in list:
            if channel["url"].lower() == url.lower():
                    list.remove(channel)
                    break
			
    common.SaveList(favoritesFile, list)
    xbmc.executebuiltin("XBMC.Container.Refresh()")

def AddNewFavortie():
    
    chName = GetKeyboardText("{0}".format(localizedString(10014).encode('utf-8'))).strip()
    if len(chName) < 1:
            return
    chUrl = GetKeyboardText("{0}".format(localizedString(10015).encode('utf-8'))).strip()
    if len(chUrl) < 1:
            return
		
    favList = common.ReadList(favoritesFile)
    for item in favList:
            if item["url"].lower() == url.lower():
                    xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, chName, localizedString(10011).encode('utf-8'), icon))
                    return
			
    data = {"url": chUrl, "image": "", "name": chName.decode("utf-8")}
    favList.append(data)
    if common.SaveList(favoritesFile, favList):
            xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}?mode=30&url=favorites')".format(AddonID))


###########################
# Ricerca aggiornamenti 
    
def checkforupdates(url,loc,aut):
    
    xbmc.log('Start check for updates')
    try:
            data = urllib2.urlopen(url).read()
            xbmc.log('read xml remote data:' + data)
    except:
            data = ""
            xbmc.log('fail read xml remote data:' + url )
    try:
            f = open(loc,'r')
            data2 = f.read().replace("\n\n", "")
            f.close()
            xbmc.log('read xml local data:' + data2)
    except:
            data2 = ""
            xbmc.log('fail read xml local data')

    version_publicada = find_single_match(data,"<version>([^<]+)</version>").strip()
    tag_publicada = find_single_match(data,"<tag>([^<]+)</tag>").strip()

    version_local = find_single_match(data2,"<version>([^<]+)</version>").strip()
    tag_local = find_single_match(data,"<tag>([^<]+)</tag>").strip()

    try:
        numero_version_publicada = int(version_publicada)
        xbmc.log('number remote version:' + version_publicada)
        numero_version_local = int(version_local)
        xbmc.log('number local version:' + version_local)
    except:
        version_publicada = ""
            
        xbmc.log('number local version:' + version_local )
        xbmc.log('Check fail !@*')
            
    if version_publicada!="" and version_local!="":
        if (numero_version_publicada > numero_version_local):

            extpath = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8")) 
            dest = addon_data_dir + '/lastupdate.zip'                
                
            UPDATE_URL = 'https://github.com/vania70/Kodi-Live-TV/raw/master/plugin.video.kodilivetv-' + tag_publicada + '.zip'
            xbmc.log('START DOWNLOAD UPDATE:' + UPDATE_URL)
                
            DownloaderClass(UPDATE_URL,dest)  

            import ziptools

            unzipper = ziptools.ziptools()
            unzipper.extract(dest,extpath)
                
            line7 = 'New version installed .....'
            line8 = 'Version: ' + tag_publicada 
                
            xbmcgui.Dialog().ok('Kodi Live TV', line7, line8)
                
            if os.remove( dest ):
                xbmc.log('TEMPORARY ZIP REMOVED')
            xbmc.executebuiltin("UpdateLocalAddons")
            xbmc.executebuiltin("UpdateAddonRepos")
            xbmc.sleep(1500)

    url = REMOTE_VERSION_FILE2
    loc = LOCAL_VERSION_FILE2
        
    try:
        data = urllib2.urlopen(url).read()
        xbmc.log('read xml remote data:' + data)
    except:
        data = ""
        xbmc.log('fail read xml remote data:' + url )
    try:
        f = open(loc,'r')
        data2 = f.read().replace("\n\n", "")
        f.close()
        xbmc.log('read xml local data:' + data2)
    except:
        data2 = ""
        xbmc.log('fail read xml local data')
            
    version_publicada = find_single_match(data,"<version>([^<]+)</version>").strip()
    tag_publicada = find_single_match(data,"<tag>([^<]+)</tag>").strip()

    version_local = find_single_match(data2,"<version>([^<]+)</version>").strip()
    dinamic_url = find_single_match(data,"<url>([^<]+)</url>").strip()
        
    try:
        numero_version_publicada = int(version_publicada)
        xbmc.log('number remote version:' + version_publicada)
        numero_version_local = int(version_local)
        xbmc.log('number local version:' + version_local)
    except:
        version_publicada = ""
                
        xbmc.log('number local version:' + version_local )
        xbmc.log('Check fail !@*')
            
    if version_publicada!="" and version_local!="":
        if (numero_version_publicada > numero_version_local):

            extpath = os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8")) 
            dest = addon_data_dir + '/temp.zip'  
                    
            urllib.urlretrieve(dinamic_url,dest)
            xbmc.log('START DOWNLOAD PARTIAL UPDATE:' + dinamic_url) 
                    
            import ziptools
            unzipper = ziptools.ziptools()
            unzipper.extract(dest,extpath)
                    
            line7 = 'Plugin data updated .....'
            line8 = 'Description: ' + tag_publicada 
                    
            xbmcgui.Dialog().ok('Kodi Live TV', line7, line8)
                    
            if os.remove( dest ): 
                xbmc.log('TEMPORARY ZIP REMOVED')
            xbmc.executebuiltin("UpdateLocalAddons")
            xbmc.executebuiltin("UpdateAddonRepos")
            u = False
        else:
            xbmc.log('No partial updates are available' )
            u = True
                        
    if aut<1 and u:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,localizedString(10044).encode('utf-8'), 4500, icon))
        xbmc.log('Check updates:No updates are available' )

###################

def get_params():
    
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
            params = sys.argv[2]
            cleanedparams = params.replace('?','')
            if (params[len(params)-1] == '/'):
                    params = params[0:len(params)-2]
            pairsofparams = cleanedparams.split('&')
            param = {}
            for i in range(len(pairsofparams)):
                    splitparams = {}
                    splitparams = pairsofparams[i].split('=')
                    if (len(splitparams)) == 2:
                            param[splitparams[0].lower()] = splitparams[1]
    return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
station = None
user_id = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    user_id = params["userid"]
except:
    pass
try:        
    rec_id = params["recid"]
except:
    pass    
try:        
    station = urllib.unquote_plus(params["station"])
except:
    pass    
    
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:
    streamtype = urllib.unquote_plus(params["streamtype"])
except:
    pass    


if url and url.find("l=chit") >= 0:
    from teleboy import *
    ListTB("it")
    url = None
elif url and url.find("l=chfr") >= 0:
    from teleboy import *
    ListTB("fr")
    url = None
elif url and url.find("l=chde") >= 0:
    from teleboy import *
    ListTB("de")
    url = None
elif url and url.find("l=chen") >= 0:
    from teleboy import *
    ListTB("en")
    url = None
if mode == None or url == None or len(url) < 1:
    Categories()
elif mode == 1:
    xml_settings = os.path.join(addon_data_dir, "settings.xml")
    if os.path.isfile(xml_settings):
        os.remove(xml_settings)
        sys.exit()
elif mode == 2:
    m3uCategory(url)
elif mode == 4 or mode == 51:
    m3uCategory(url,False)	
elif mode == 3 or mode == 32:
    PlayUrl(name, url, iconimage)
elif mode == 5:
    maxbitrate = Addon.getSetting('BitRateMax')
    if Addon.getSetting('use_simple') == "true":
        simpledownloader = True
    else:
        simpledownloader = False
    sys.path.insert(0, f4mProxy)
    from F4mProxy import f4mProxyHelper
    player=f4mProxyHelper()
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
    if streamtype == "HLS":
        maxbitrate = 9000000
    player.playF4mLink(url, name, None, True, maxbitrate, simpledownloader, None, streamtype, False, None, iconimage)
        
elif mode == 6:
    name = name.replace(".","-")
    VideoDownload(url,name)
    
elif mode == 7 or mode == 59:
    ext = url.split('.')[-1]
    DF = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('download_path')
    
    if not DF=='':  
        dpath = DF
    else:    
        dpath = addon_data_dir
          
    import fileDownloader
    file = dpath + name + '.' + ext
    downloader = fileDownloader.DownloadFile( url , file)
    
    notifica = 1
    
    loc1 = file + ".resume"
    loc2 = file + ".stopped"
    
    xbmc.executebuiltin("XBMC.Container.Refresh()")
    
    if os.path.isfile(loc2) and mode == 7:
        os.rename(loc2,loc1)
    
    if os.path.isfile( file ):
        Resume = TestDownload( file )
        if  Resume == True:
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, name + ': ' + localizedString(10211).encode('utf-8'), 6000, icon))
            downloader.resume()
            notifica = 3
        else:
            notifica = 2
    else:
        downloader.download()
    
    if notifica == 1:
        if os.path.isfile(loc1):
            os.remove(loc1)
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, name + ': ' + localizedString(10209).encode('utf-8'), 6000, icon))

    elif notifica == 2:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, name + ': ' + localizedString(10210).encode('utf-8'), 6000, icon))
    else:
        size = os.stat(file).st_size
        fullsize = size
        
        if os.path.isfile(loc1):
            fsize = common.ReadFile(loc1).replace("\r","").split("\n")
            fullsize = int(fsize[0])
            
        if not int(size)==fullsize:
            xbmc.sleep(2500)
            xbmc.log("$$$  --  Download Retry --  $$$")
            xbmc.executebuiltin('XBMC.RunPlugin(plugin://plugin.video.kodilivetv/?url=' + urllib.quote_plus(url) + '&name=' + name + '&mode=59)')
        else:
            if os.path.isfile(loc1):
                os.remove(loc1)
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, name + ': ' + localizedString(10209).encode('utf-8'), 6000, icon))
    
elif mode == 57:
    DF = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('download_path')
    ext = url.split('.')[-1]
    if not DF=='':  
        dpath = DF
    else:    
        dpath = addon_data_dir

    file = dpath + name + '.' + ext
    loc1 = file + ".resume"
    loc2 = file + ".stopped"
    #content = common.ReadFile(loc1)
    #os.remove(loc1)
    #write_file(loc2,content)
    os.rename(loc1,loc2)
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, name + ': ' + localizedString(10208).encode('utf-8'), 6000, icon))
    xbmc.executebuiltin("XBMC.Container.Refresh()")
    sys.exit()
elif mode == 58:
    DF = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('download_path')
    ext = url.split('.')[-1]
    if not DF=='':  
        dpath = DF
    else:    
        dpath = addon_data_dir
    
    file = dpath + name + '.' + ext
    if os.path.isfile(file):
        os.remove(file)
    if os.path.isfile(file + ".stopped"):
        os.remove(file + ".stopped")
    if os.path.isfile(file + ".resume"):
        os.remove(file + ".resume")
        
    xbmc.executebuiltin("XBMC.Container.Refresh()")
    
elif mode == 10:
    shutil.copyfile( PATCH_SD , SD_FILE )
    write_file(PATCHED,"")

    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, "SimpleDownloader.py is patched", 5000, icon))
    xbmc.sleep(1000)
    sys.exit()
    
elif mode == 20:
    AddNewList()
elif mode == 21 or mode == 54 or mode == 60:
    PMFolder( url )
elif mode == 22:
    RemoveFromLists(url)
elif mode == 23:
    ChangeName(name, playlistsFile2, "name", 10004)
elif mode == 24:
    ChangeUrl(url, playlistsFile2, "url", 10005)
elif mode == 61:
    ChangeName(name, playlistsFile4, "name", 10004)        
elif mode == 25:
    importList()
elif mode == 26:
    if os.path.isfile( playlistsFile3 ) :
        if os.path.isfile( playlistsFile2 ) : os.remove( playlistsFile2 )
        shutil.copyfile( playlistsFile3, playlistsFile2 )
        xbmc.sleep ( 200 )
        os.remove( playlistsFile3 )
        xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}')".format(AddonID))
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,localizedString(10125).encode('utf-8'), 3600, icon)) 
    else:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName,localizedString(10126).encode('utf-8'), 3600, icon)) 
            
elif mode == 27:
    from teleboy import *
    try:
        json = get_videoJson( user_id, station)
        if not json:
            exit( 1)

        title = json["data"]["epg"]["current"]["title"]
        url = json["data"]["stream"]["url"]

        if not url: exit( 1)
        img = get_stationLogoURL( station)
        Player = xbmcaddon.Addon('plugin.video.kodilivetv').getSetting('player')
        if  Addon.getSetting('player') == "true":
            play_url2( url, title, img )  
        else:
            play_url( url, title, img )
    except:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, "Swiss IP needed. Your bags ready!", 3600, icon))

elif mode == 28:
    from teleboy import *
    show_recordings( user_id)
    
elif mode == 29:
    from teleboy import *
    url = "stream/record/%s" % rec_id
    json    = fetchApiJson( user_id, url)
    title = json["data"]["record"]["title"]
    url   = json["data"]["stream"]["url"]
    img = REC_ICON
    play_url( url, title, img )

elif mode == 30:
    ListFavorites()
elif mode == 31: 
    AddFavorites(url, iconimage, name)
elif mode == 55:
    RemoveDirFromLists(url,name)
elif mode == 56:
    os.remove( os.path.join(pwdir, base64.standard_b64encode(url))) 
    xbmc.executebuiltin("XBMC.Container.Refresh()")
elif mode == 33:
    RemoveFavorties(url)
elif mode == 34:
    AddNewFavortie()
elif mode == 35:
    ListSub(Italian)
elif mode == 36:
    ListSub(French)
elif mode == 37:
    ListSub(German)
elif mode == 38:
    ListSub(English)
elif mode == 39:
    PM_index()
elif mode == 40:
    common.DelFile(playlistsFile2)
    sys.exit()
elif mode == 41:
    common.DelFile(favoritesFile)
    sys.exit()
elif mode == 42:
    write_xml()
    sys.exit()
elif mode == 43:
    restore_xml()
    sys.exit()   
elif mode == 44:
    remove_xml()
    sys.exit()
elif mode == 45:        
    clean_cache()
    sys.exit()
elif mode == 46:       
    checkforupdates(REMOTE_VERSION_FILE, LOCAL_VERSION_FILE,0)
    #write_file(Tfile , '*')        
    sys.exit()
elif mode == 47:
    xbmc.executebuiltin("StopPVRManager")
    xbmc.executebuiltin("StartPVRManager") 
    sys.exit()
elif mode == 48:
    common.Open_Netflix()        
elif mode == 49:
    common.Open_Paypal()
elif mode == 50:
    print '--- Playing "{0}". {1}'.format(name, url)
    listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
    listitem.setInfo(type="Video", infoLabels={ "Title": name })
    xbmc.Player().play( url , listitem)
elif mode == 52:
    return_value = xbmcgui.Dialog().yesno(localizedString(10045).encode('utf-8'), localizedString(10046).encode('utf-8') + " " + name + " ?")

    if return_value == 0:
        sys.exit()
    else:
        try:
            file = os.path.join(url)
            xbmcvfs.delete(file)
            if os.path.isfile(file + ".stopped"):
                os.remove(file + ".stopped")
            if os.path.isfile(file + ".resume"):
                os.remove(file + ".resume")
            
            xbmc.executebuiltin("XBMC.Container.Refresh()")
            xbmc.sleep(750)
            if xbmcvfs.exists(os.path.join(url)):
                xbmc.sleep(1800)
            if xbmcvfs.exists(os.path.join(url)):
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, name + ' ' + localizedString(10201).encode('utf-8'), 6700, icon))
            else:    
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, name + ' ' + localizedString(10200).encode('utf-8'), 6700, icon))
        except:
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, name + ' ' + localizedString(10201).encode('utf-8'), 6700, icon))
    sys.exit()
elif mode == 53:
    string = GetKeyboardText(localizedString(10203).encode('utf-8'), name)
    if len(string) < 1:
        sys.exit()
    else:
        nurl = url.replace(name,string)
        xbmcvfs.rename(os.path.join(url) ,os.path.join(nurl))
        xbmc.executebuiltin("XBMC.Container.Refresh()")
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(AddonName, name + ' ' + localizedString(10202).encode('utf-8'), 5200, icon))
        sys.exit()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
