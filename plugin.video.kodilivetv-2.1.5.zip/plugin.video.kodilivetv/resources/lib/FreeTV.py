# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin
import base64 
import urllib2,urllib,cgi, re, sys, platform

try:
    import json
except:
    import simplejson as json

def getUrl(url, cookieJar=None,post=None, timeout=20, headers=None,jsonpost=False):

    cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
    opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36')
    if headers:
        for h,hv in headers:
            req.add_header(h,hv)
    if jsonpost:
        req.add_header('Content-Type', 'application/json')
    response = opener.open(req,post,timeout=timeout)
    if response.info().get('Content-Encoding') == 'gzip':
            from StringIO import StringIO
            import gzip
            buf = StringIO( response.read())
            f = gzip.GzipFile(fileobj=buf)
            link = f.read()
    else:
        link=response.read()
    response.close()
    return link;

def FixBitrate(urlToPlay,name):
    if name.find("HD")>-1:
        urlToPlay = urlToPlay.replace("/3305000/","/4240000/")
        urlToPlay = urlToPlay.replace("/2290000/","/4240000/")
        urlToPlay = urlToPlay.replace("/1368000/","/4240000/")
    else:
        urlToPlay = urlToPlay.replace("/3305000/","/2290000/")
        urlToPlay = urlToPlay.replace("/1368000/","/2290000/")
    
    return urlToPlay

def MoreChannels(urlToPlay,name):

    #italian channels
    if name.find("Cielo")>-1:
        urlToPlay = urlToPlay.replace("/3003/","/3041/")
    elif name.find("TV 8")>-1:    
        urlToPlay = urlToPlay.replace("/3004/","/3009/")
    #french channels
    elif name.find("Arte HD FR")>-1:
        urlToPlay = urlToPlay.replace("/2010/","/2029/")
    elif name.find("RTS 1 HD")>-1:
        urlToPlay = urlToPlay.replace("/2008/","/2034/")       
    elif name.find("RTS 2 HD")>-1:
        urlToPlay = urlToPlay.replace("/2008/","/2035/") 
    elif name.find("M6 HD")>-1:
        urlToPlay = urlToPlay.replace("/2010/","/2026/")
    elif name.find("France Ô")>-1:
        urlToPlay = urlToPlay.replace("/2009/","/2015/")        
    elif name.find("Gulli")>-1:
        urlToPlay = urlToPlay.replace("/2009/","/2011/") 
    #german channels
    elif name.find("ZDFneo HD")>-1:
        urlToPlay = urlToPlay.replace("/1008/","/1121/")
    elif name.find("ZDFkultur HD")>-1:
        urlToPlay = urlToPlay.replace("/1008/","/1119/")
    elif name.find("ZDFinfo HD")>-1:
        urlToPlay = urlToPlay.replace("/1009/","/1118/")
        
    return urlToPlay

def PlayOtherUrl ( url,name ):

    url=base64.b64decode(url)

    if url.startswith('cid:'): url=base64.b64decode('aHR0cDovL2ZlcnJhcmlsYi5qZW10di5jb20vaW5kZXgucGhwLzJfNS9neG1sL3BsYXkvJXM=')%url.replace('cid:','')
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Fetching Streaming Info')
    progress.update( 10, "", "Finding links..", "" )

    progress.update( 35, "", "Preparing url..", "" )
    url = url.split('safe:')[1]
    import websocket
    ws = websocket.WebSocket()
    
    try:    
        header=["Origin: http://customer.safersurf.com","User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36"]
        ws.connect("ws://52.48.86.135:1337/tb/m3u8/master/siteid/customer.onlinetv",header=header)
        jsdata=''
        ws.send(jsdata)
        result = ws.recv()   
        progress.update( 75, "", "Preparing url..", "" )
        jsdata='[{"key":"type","value":"channelrequest"},{"key":"dbid","value":"%s"},{"key":"tbid","value":""},{"key":"format","value":"masterm3u8"},{"key":"proxify","value":"true"},{"key":"bitrate","value":"2290000"},{"key":"maxbitrate","value":"4240000"}]'%url
        ws.send(jsdata)
        result = ws.recv()

        headers = [('Referer', 'http://customer.safersurf.com/onlinetv.html'),('User-Agent','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'),('Origin','http://customer.safersurf.com')]

        url=re.findall('[\'"](http.*?)[\'"]',result)[0]
        result=getUrl(url,headers=headers)
        urlToPlay=re.findall('(http.*?)\s',result)[-1]
    except:
        return
    
    import random
    listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ) )
    listitem.setProperty('IsPlayable', 'false')
    if name.find("HD")>-1:
        urlToPlay = urlToPlay.replace("/3305000/","/4240000/")
        urlToPlay = urlToPlay.replace("/2290000/","/4240000/")
        urlToPlay = urlToPlay.replace("/1368000/","/4240000/")
    else:
        urlToPlay = urlToPlay.replace("/3305000/","/2290000/")
        urlToPlay = urlToPlay.replace("/1368000/","/2290000/")
    
    urlToPlay = FixBitrate(urlToPlay,name)
    urlToPlay = MoreChannels(urlToPlay,name)
    
    progress.update( 99, "", "Done..", "" )
    xbmc.Player(  ).play( urlToPlay+'|Origin=http://customer.safersurf.com&User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36&Referer=http://customer.safersurf.com/onlinetv.html', listitem)
    
    xbmc.sleep(1200)
    progress.update( 100, "", "Enjoy your viewing..", "" )
    xbmc.sleep(1250)
    progress.close()
    
    if not 'win32' in sys.platform:
        if not platform.architecture()[0] == '64bit':
            xbmc.sleep(2100)
        xbmc.sleep(1000)
        xbmc.executebuiltin('XBMC.PlayerControl(Play)')
    
     
